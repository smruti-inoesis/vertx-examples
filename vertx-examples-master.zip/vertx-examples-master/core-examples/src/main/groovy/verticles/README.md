This directory contains examples of the different _formats_ supported to develop Groovy verticles. 
**Do not remove**, the files are not generated. 
