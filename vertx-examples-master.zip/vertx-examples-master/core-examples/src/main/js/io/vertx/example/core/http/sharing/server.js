vertx.deployVerticle("io.vertx.example.core.http.sharing.HttpServerVerticle", {
  "instances" : 2
});
