This directory is an example of verticles packaged as NPM. 
**Do not remove**, the files are not generated. 
